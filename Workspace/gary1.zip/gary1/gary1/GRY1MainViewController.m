//
//  GRY1MainViewController.m
//  gary1
//
//  Created by 薛洪 on 13-11-25.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import "GRY1MainViewController.h"
#import "GRY1BabyRepo.h"

@interface GRY1MainViewController ()

@end

@implementation GRY1MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        NSLog(@"Custom init for gry1 main controller");
        NSLog(@"Creating my baby");
        _myBaby = [[GRY1BabyService alloc] init];
        NSLog(@"Baby created");
        NSLog(@"Creating breed controller");
        breedController = [[GRY1BreedViewController alloc] init];
        breedController.delegate = self;
        historyController = [[GRY1HistoryViewController alloc] init];
        historyController.delegate = self;
        playController = [[GRY1PlayViewController alloc] init];
        playController.delegate = self;
        NSLog(@"Breed controller created");
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction) onBtnBreedClick:(id)sender{
    if([self checkUnFinishButExcludeState:GRY1BabyStateEnum_IN_BREED]==false){
        nextController = breedController;
        return;
    }
    [self loadBreedController];
}

-(void) loadBreedController{
    NSDate *lastBreedTime = [_myBaby getLastBreedStartTime];
    NSLog(@"Breed button clicked");
    [self presentViewController:breedController animated:true completion:nil];
    NSLog(@"Breed controller presented, loading state...");
    [breedController loadStateForLastBreedTime: [_myBaby getState] withLastBreedTime:lastBreedTime];
    NSLog(@"State loaded as %d and start time is %@", [_myBaby getState], lastBreedTime);
}

-(void)onBtnHistoryClick:(id)sender{
    [historyController setBaby:_myBaby];
    [self presentViewController:historyController animated:true completion:nil];
}

-(void)onBtnPlayClick:(id)sender{
    if([self checkUnFinishButExcludeState:GRY1BabyStateEnum_IN_PLAY]==false){
        nextController = playController;
        return;
    }
    [self loadPlayController];
}

-(void) loadPlayController{
    NSDate *lastPlayTime = [_myBaby getLastPlayStartTime];
    [self presentViewController:playController animated:true completion:nil];
    [playController loadStateForLastPlayTime:[_myBaby getState] withLastPlayTime:lastPlayTime];
}

-(void) didConfirmStartBreed:(GRY1BreedViewController *)controller{
    NSLog(@"Confirm of start breed now");
    [_myBaby startBreed:[NSDate date]];
}

-(void) didConfirmLastBreedDuration:(GRY1BreedViewController *)controller lastBreedDuration:(NSTimeInterval) duration{
    NSLog(@"==> confirm of end breed by duration: %f", duration);
    [_myBaby endBreedByDuraiton:duration];
    if(nextController){
        [self showNextController];
    }
}

-(void)didConfirmStartPlay:(GRY1PlayViewController *)controller{
    NSLog(@"Confirm of start play now");
    [_myBaby startPlay:[NSDate date]];
}

-(void)didConfirmLastPlayDuration:(GRY1PlayViewController *)controller lastPlayDuration:(NSTimeInterval)duration{
    NSLog(@"==> confirm of end play by duration: %f", duration);
    [_myBaby endPlayByDuraiton:duration];
    if(nextController){
        [self showNextController];
    }
}

-(void)didCancelBreedLog:(GRY1BreedViewController *)controller{
    nextController = nil;
}

-(void)didCancelPlayLog:(GRY1PlayViewController *)controller{
    nextController = nil;
}

-(void)didGoBack:(GRY1HistoryViewController *)controller{
    
}

-(bool)checkUnFinishButExcludeState: (GRY1BabyStateEnum) excludeState{
    GRY1BabyStateEnum state = [_myBaby getState];
    if(state == excludeState){
        return true;
    }
    switch (state) {
        case GRY1BabyStateEnum_IN_BREED:
            [self loadBreedController];
            return false;
        case GRY1BabyStateEnum_IN_PLAY:
            [self loadPlayController];
            return false;
        default:
            return true;
    }
}

-(void) showNextController{
    if(nextController == breedController){
        [self loadBreedController];
    }else if(nextController == playController){
        [self loadPlayController];
    }
}

@end
