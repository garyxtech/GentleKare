//
//  GRY1BabyRepo.h
//  gary1
//
//  Created by 薛洪 on 13-11-27.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Baby.h"
#import "Action.h"

@interface GRY1BabyRepo : NSObject

+(void) initStore;

+(void) save;

+(Baby*) findBabyByName: (NSString*) name;

+(Baby*) addNewBabyForName:(NSString*) name;

+(Action*) addNewActionForType:(GRY1ActionEnum) type;

@end
