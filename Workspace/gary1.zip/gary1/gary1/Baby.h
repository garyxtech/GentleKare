//
//  Baby.h
//  gary1
//
//  Created by 薛洪 on 13-11-28.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Action;

@interface Baby : NSManagedObject

@property (nonatomic) NSTimeInterval birthday;
@property (nonatomic) int32_t gender;
@property (nonatomic, retain) NSString * name;
@property (nonatomic) int32_t state;
@property (nonatomic, retain) NSSet *recentActions;
@end

@interface Baby (CoreDataGeneratedAccessors)

- (void)addRecentActionsObject:(Action *)value;
- (void)removeRecentActionsObject:(Action *)value;
- (void)addRecentActions:(NSSet *)values;
- (void)removeRecentActions:(NSSet *)values;

@end
