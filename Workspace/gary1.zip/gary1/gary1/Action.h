//
//  Action.h
//  gary1
//
//  Created by 薛洪 on 13-11-28.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Baby;

@interface Action : NSManagedObject

@property (nonatomic) NSTimeInterval from;
@property (nonatomic) NSTimeInterval to;
@property (nonatomic) int32_t type;
@property (nonatomic, retain) Baby *belongBaby;

@end
