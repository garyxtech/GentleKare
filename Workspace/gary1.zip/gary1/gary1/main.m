//
//  main.m
//  gary1
//
//  Created by 薛洪 on 13-11-24.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GRY1AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GRY1AppDelegate class]));
    }
}
