//
//  GRY1BabyState.m
//  gary1
//
//  Created by 薛洪 on 13-11-25.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import "GRY1BabyService.h"

@implementation GRY1BabyService

-(id) init{
    self = [super init];
    if(self){
        NSLog(@"Initing baby");
        [GRY1BabyRepo initStore];
        _baby = [GRY1BabyRepo findBabyByName:@"川川"];
        if(_baby==nil){
            [GRY1BabyRepo addNewBabyForName:@"川川"];
        }
        _baby = [GRY1BabyRepo findBabyByName:@"川川"];
        NSLog(@"Baby's name is %@", _baby.name);
        _groupForDay = [[NSMutableArray alloc] init];
    }
    return self;
}

-(GRY1BabyStateEnum) getState{
    return (GRY1BabyStateEnum)_baby.state;
}

-(void) startBreed:(NSDate *)startTime{
    
    NSLog(@"Baby start breeding...");
    assert(_baby.state!= GRY1BabyStateEnum_IN_BREED);
    
    NSLog(@"Create new breed action");
    Action* breedAction = [GRY1BabyRepo addNewActionForType:GRY1ActionEnum_BREED];
    
    NSLog(@"Start breed");
    breedAction.from = [[NSDate date] timeIntervalSince1970];
    
    //[_baby addRecentActionsObject:breedAction];
    breedAction.belongBaby = _baby;
    
    _baby.state = GRY1BabyStateEnum_IN_BREED;
    
    [GRY1BabyRepo save];
    
    [self _updateDayGroup];
    
}

-(void) endBreedByEndTime:(NSDate *)endTime{
    
    NSLog(@"Baby end breed by time");
    Action *lastBreed = [self _getLastActionByType:GRY1ActionEnum_BREED];
    NSLog(@"Found last breed action is %@", lastBreed);
    assert(lastBreed);
    
    NSLog(@"Finish last breed at %@", endTime);
    lastBreed.to = [endTime timeIntervalSince1970];
    
    _baby.state = GRY1BabyStateEnum_IDLE;
    
    [GRY1BabyRepo save];
    
    [self _updateDayGroup];
    
}

-(void) endBreedByDuraiton:(NSTimeInterval) duration{
    
    NSLog(@"Baby end breed by duration");
    Action *lastBreed = [self _getLastActionByType:GRY1ActionEnum_BREED];
    NSLog(@"Found last breed action is %@", lastBreed);
    assert(lastBreed);
    
    NSDate* from = [NSDate dateWithTimeIntervalSince1970: lastBreed.from];
    NSLog(@"Last from is %@", from);
    NSDate* to = [from dateByAddingTimeInterval:duration];
    NSLog(@"New end time for last from is %@", to);
    NSLog(@"Finish last breed at %@", to);
    lastBreed.to = [to timeIntervalSince1970];
    
    _baby.state = GRY1BabyStateEnum_IDLE;
    
    [GRY1BabyRepo save];
    
    [self _updateDayGroup];
    
}

-(NSDate *)getLastBreedStartTime{
    
    Action *lastBreed = [self _getLastActionByType:GRY1ActionEnum_BREED];
    
    if(lastBreed){
        if(lastBreed.to!=0){
            return nil;
        }else{
            return [NSDate dateWithTimeIntervalSince1970:lastBreed.from];
        }
    }else{
        return nil;
    }
}

-(NSArray *)getRecentActions{
    return [NSArray arrayWithArray: [_baby.recentActions allObjects]];
}

-(NSInteger)getRecentActionGroupCount{
    return [_groupForDay count];
}

-(NSString *)getGroupTitleForIdx:(NSInteger)groupIdx{
    if(groupIdx >= [_groupForDay count]){
        return @"[未知]";
    }else{
        NSDate *compareTime = [_groupForDay objectAtIndex:groupIdx];
        return [GRY1Util dateToStrAsDayOnly:compareTime];
    }
}

-(NSInteger) getActionCountForGroupIdx: (NSInteger) groupIdx{
    NSArray* recentActions = [self getRecentActions];
    return [[recentActions filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        Action *action = (Action*) evaluatedObject;
        NSDate *compareTime = [self getKeyTime:action];
        compareTime = [GRY1Util stripTime:compareTime];
        NSUInteger idx = [_groupForDay indexOfObject:compareTime];
        if(idx==groupIdx){
            return true;
        }else{
            return false;
        }
    }]] count];
}

-(Action *) getActionForIdx: (NSInteger) actionIdx forGroupIdx:(NSInteger) groupIdx{
    NSArray* recentActions = [self getRecentActions];
    NSArray *filterActions = [recentActions filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        Action *action = (Action*) evaluatedObject;
        NSDate *compareTime = [self getKeyTime:action];
        compareTime = [GRY1Util stripTime:compareTime];        
        NSUInteger idx = [_groupForDay indexOfObject:compareTime];
        if(idx==groupIdx){
            return true;
        }else{
            return false;
        }
    }]];
    if(actionIdx >= [filterActions count]){
        return nil;
    }else{
        return [filterActions objectAtIndex:actionIdx];
    }
}



-(void) startPlay:(NSDate *)startTime{
    
    NSLog(@"Baby start playing...");
    assert(_baby.state!= GRY1BabyStateEnum_IN_PLAY);
    
    NSLog(@"Create new play action");
    Action *playAction = [GRY1BabyRepo addNewActionForType:GRY1ActionEnum_PLAY];
    
    NSLog(@"Start play");
    playAction.from = [startTime timeIntervalSince1970];
    
    //[_baby addRecentActionsObject:playAction];
    playAction.belongBaby = _baby;
    
    _baby.state = GRY1BabyStateEnum_IN_PLAY;
    
    [GRY1BabyRepo save];
    
    [self _updateDayGroup];
    
}

-(void) endPlayByEndTime:(NSDate *)endTime{
    
    NSLog(@"Baby end play by time");
    Action *lastPlay = [self _getLastActionByType:GRY1ActionEnum_PLAY];
    NSLog(@"Found last play action is %@", lastPlay);
    assert(lastPlay);
    
    NSLog(@"Finish last play at %@", endTime);
    lastPlay.to = [endTime timeIntervalSince1970];
    
    _baby.state = GRY1BabyStateEnum_IDLE;
    
    [GRY1BabyRepo save];
    
    [self _updateDayGroup];
    
}

-(void) endPlayByDuraiton:(NSTimeInterval) duration{
    
    NSLog(@"Baby end play by duration");
    Action *lastPlay = [self _getLastActionByType:GRY1ActionEnum_PLAY];
    NSLog(@"Found last play action is %@", lastPlay);
    assert(lastPlay);
    
    NSDate* from = [NSDate dateWithTimeIntervalSince1970: lastPlay.from];
    NSLog(@"Last from is %@", from);
    NSDate* to = [from dateByAddingTimeInterval:duration];
    NSLog(@"New end time for last from is %@", to);
    NSLog(@"Finish last play at %@", to);
    lastPlay.to = [to timeIntervalSince1970];
    
    _baby.state = GRY1BabyStateEnum_IDLE;
    
    [self _updateDayGroup];
    
}

-(NSDate *)getLastPlayStartTime{
    Action *lastPlay = [self _getLastActionByType:GRY1ActionEnum_PLAY];
    if(lastPlay){
        if(lastPlay.to!=0){
            return nil;
        }else{
            return [NSDate dateWithTimeIntervalSince1970:lastPlay.from];
        }
    }else{
        return nil;
    }
}


-(void) _updateDayGroup{
    [_groupForDay removeAllObjects];
    NSArray* recentActions = [NSArray arrayWithArray:[_baby.recentActions allObjects]];
    for(Action *currAction in recentActions){
        NSDate *dateDay = [GRY1Util stripTime: [self getKeyTime: currAction]];
        if([_groupForDay containsObject:dateDay]){
            ;
        }else{
            if(dateDay){
                [_groupForDay addObject:dateDay];
            }
        }
    }
}

-(Action *) _getLastActionByType: (GRY1ActionEnum) type{
    NSLog(@"Getting last action by type %d", type);
    NSArray* recentActions = [NSArray arrayWithArray:[_baby.recentActions allObjects]];
    for(Action *curr in [recentActions reverseObjectEnumerator]){
        if(curr.type == type){
            NSLog(@"Found one, return");
            return curr;
        }
    }
    return nil;
}

-(NSDate*) getKeyTime:(Action*) action{
    if(action.to==0){
        return [NSDate dateWithTimeIntervalSince1970:action.from];
    }else{
        return [NSDate dateWithTimeIntervalSince1970:action.to];
    }
}

@end
