//
//  GRY1HistoryViewController.m
//  gary1
//
//  Created by 薛洪 on 13-11-26.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import "GRY1HistoryViewController.h"

@interface GRY1HistoryViewController ()

@end

@implementation GRY1HistoryViewController

@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

-(void)viewDidAppear:(BOOL)animated{
    [tblActionLog reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)btnBackClick:(id)sender{
    [delegate didGoBack:self];
    [self dismissViewControllerAnimated:true completion:nil];
}

-(void) setBaby: (GRY1BabyService*) baby{
    _baby = baby;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [_baby getRecentActionGroupCount];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_baby getActionCountForGroupIdx:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CELL_ID = @"HISTORY_TABLE_CELL_ID";
    UITableViewCell *cell = [tblActionLog dequeueReusableCellWithIdentifier:CELL_ID];
    if(cell==nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_ID];
    }
    Action *action = [_baby getActionForIdx:indexPath.row forGroupIdx:indexPath.section];
    if(action){
        [cell.textLabel setText:[NSString stringWithFormat:@"    %@", [self getActionDipslay:action]]];
    }else{
        [cell.textLabel setText: @"    未知"];
    }
    
    UIImageView *backgroundCellImage=[[UIImageView alloc] initWithFrame:CGRectMake(2, 2, 30, 30)];
    
    backgroundCellImage.image=[UIImage imageNamed:[self getImageNameByType:action.type]];
    
    [cell.contentView addSubview:backgroundCellImage];
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [_baby getGroupTitleForIdx:section];
}

-(NSString*) getImageNameByType: (GRY1ActionEnum) type{
    switch (type) {
        case GRY1ActionEnum_BREED:
            return @"bottle.png";
        case GRY1ActionEnum_PLAY:
            return @"play.png";
        default:
            return @"";
    }
}

-(NSString*) getActionDipslay:(Action*) action{
    NSString* type = nil;
    switch (action.type) {
        case GRY1ActionEnum_BREED:
            type = @"喂奶";
            break;
        case GRY1ActionEnum_PLAY:
            type = @"玩耍";
            break;
        default:
            break;
    }
    NSDate* from = [NSDate dateWithTimeIntervalSince1970:action.from];
    NSDate* to = nil;
    if(action.to!=0){
        to = [NSDate dateWithTimeIntervalSince1970:action.to];
    }
    NSString* fromStr = [GRY1Util dateToStrAsTimeOnly:from];
    NSString* toStr = [GRY1Util dateToStrAsTimeOnly:to];
    return [NSString stringWithFormat:@"  %@, 从 %@ 到 %@", type, fromStr, toStr];
}


@end
