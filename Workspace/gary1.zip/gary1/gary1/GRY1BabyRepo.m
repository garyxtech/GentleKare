//
//  GRY1BabyRepo.m
//  gary1
//
//  Created by 薛洪 on 13-11-27.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import "GRY1BabyRepo.h"

@implementation GRY1BabyRepo

static NSManagedObjectModel* _model;
static NSPersistentStoreCoordinator* _coord;
static NSManagedObjectContext* _store;

+(void)initStore{
    NSError* error;
    _model = [NSManagedObjectModel mergedModelFromBundles:nil];
    _coord = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:_model];
    [_coord addPersistentStoreWithType:NSInMemoryStoreType configuration:nil URL:nil options:nil error:&error];
    _store = [[NSManagedObjectContext alloc] init];
    [_store setPersistentStoreCoordinator:_coord];
    [_store setUndoManager:nil];
}

+(void)save{
    NSError* error;
    if(![_store save:&error]){
        NSLog(@"Fail to save");
    }else{
        NSLog(@"Success to save");
    }
}

+(Baby*)findBabyByName:(NSString *)name{
    NSDictionary* para = [NSDictionary dictionaryWithObjectsAndKeys:name, @"NAME", nil];
    NSFetchRequest* fetch = [_model fetchRequestFromTemplateWithName:@"FindBabyByName" substitutionVariables:para];
    NSError* error;
    NSArray* result = [_store executeFetchRequest:fetch error:&error];
    if(result && [result count]>0){
        NSLog(@"Find baby with name %@", ((Baby*) [result objectAtIndex:0]).name);
        return (Baby*) [result objectAtIndex:0];
    }else{
        NSLog(@"Fail to find any baby match predication");
        return nil;
    }
}

+(Baby*)addNewBabyForName:(NSString *)name{
    Baby* newBaby = [NSEntityDescription insertNewObjectForEntityForName:@"Baby" inManagedObjectContext:_store];
    newBaby.name = name;
    return newBaby;
}

+(Action *)addNewActionForType:(GRY1ActionEnum)type{
    Action* newAction = [NSEntityDescription insertNewObjectForEntityForName:@"Action" inManagedObjectContext:_store];
    newAction.type = type;
    return newAction;
}

@end
