//
//  GRY1AppDelegate.h
//  gary1
//
//  Created by 薛洪 on 13-11-24.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRY1AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
