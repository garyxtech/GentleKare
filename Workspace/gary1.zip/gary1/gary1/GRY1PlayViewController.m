//
//  GRY1PlayViewController.m
//  gary1
//
//  Created by 薛洪 on 13-11-27.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import "GRY1PlayViewController.h"

@interface GRY1PlayViewController ()
@end

@implementation GRY1PlayViewController

@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)btnStartPlayClick:(id)sender{
    [self.delegate didConfirmStartPlay:self];
    [self dismissViewControllerAnimated:true completion:nil];
}

-(IBAction)btnCancelClick:(id)sender{
    [self dismissViewControllerAnimated:true completion:nil];
}

-(IBAction)btnEndPlayClick:(id)sender{
    NSTimeInterval currentDuration = [self _getCurrentDuration];
    [self dismissViewControllerAnimated:true completion:^{
        [self.delegate didConfirmLastPlayDuration:self lastPlayDuration:currentDuration];
    }];
}

-(void) loadStateForLastPlayTime:(GRY1BabyStateEnum)newState withLastPlayTime:(NSDate *)from{
    state = newState;
    _playTimeFrom = from;
    if(state == GRY1BabyStateEnum_IN_PLAY){
        btnStartPlay.hidden = true;
        vwStopPlay.hidden = false;
        [lblCurrentTimePrompt setText:[NSString stringWithFormat:@"上次开始玩耍时间是:"]];
        [lblCurrentTime setText:[GRY1Util dateToStr:_playTimeFrom]];
    }else{
        btnStartPlay.hidden=false;
        vwStopPlay.hidden=true;
        [lblCurrentTimePrompt setText:[NSString stringWithFormat:@"现在时间是:"]];
        [lblCurrentTime setText:[GRY1Util dateToStr:[NSDate date]]];
    }
}

-(IBAction) btnSetLastPlayTimeClick:(id)sender{
    [self _showTimePickForDate:true];
}

-(IBAction) btnSetLastPlayDurationClick:(id)sender{
    [self _showTimePickForDate:false];
}

-(IBAction)btnDatePickClick:(id)sender{
    [self _closeAndUpdateDatePick];
}

-(void) _showTimePickForDate:(bool) isForDate{
    _isLastPickForDate = isForDate;
    if(isForDate){
        [pckDate setDatePickerMode:UIDatePickerModeDateAndTime];
    }else{
        [pckDate setDatePickerMode:UIDatePickerModeCountDownTimer];
    }
    vwDatePick.hidden = false;
}

-(void) _closeAndUpdateDatePick{
    
    _lastPickDate = nil;
    _lastPickDuration = -1;
    [btnSetLastPlayEndTime setTitle:@"设定" forState:UIControlStateNormal];
    [btnSetLastPlayDuration setTitle:@"设定" forState:UIControlStateNormal];
    
    if(_isLastPickForDate){
        _lastPickDate = [pckDate date];
        [btnSetLastPlayEndTime setTitle:[GRY1Util dateToStr:_lastPickDate] forState:UIControlStateNormal];
    }else{
        NSDate *time = [pckDate date];
        NSTimeInterval duration = [GRY1Util getSeconds:time];
        int minute = (int) (duration/60);
        _lastPickDuration = duration;
        [btnSetLastPlayDuration setTitle:[NSString stringWithFormat:@"%d minute(s)", minute] forState:UIControlStateNormal];
    }
    
    vwDatePick.hidden = true;
}

-(NSTimeInterval) _getCurrentDuration{
    assert(_playTimeFrom);
    if(_isLastPickForDate){
        return [_lastPickDate timeIntervalSinceDate:_playTimeFrom];
    }else{
        return _lastPickDuration;
    }
}
@end
