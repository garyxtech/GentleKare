//
//  Baby.m
//  gary1
//
//  Created by 薛洪 on 13-11-28.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import "Baby.h"
#import "Action.h"


@implementation Baby

@dynamic birthday;
@dynamic gender;
@dynamic name;
@dynamic state;
@dynamic recentActions;

@end
