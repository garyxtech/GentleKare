//
//  GRY1PlayViewController.h
//  gary1
//
//  Created by 薛洪 on 13-11-27.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import <UIKit/UIKit.h>


@class GRY1PlayViewController;

@protocol GRY1PlayViewControllerDelegate <NSObject>
-(void) didConfirmStartPlay: (GRY1PlayViewController*) controller;
-(void) didConfirmLastPlayDuration: (GRY1PlayViewController*) controller lastPlayDuration:(NSTimeInterval) duration;
-(void) didCancelPlayLog: (GRY1PlayViewController*) controller;
@end

@interface GRY1PlayViewController : UIViewController
{
    GRY1BabyStateEnum state;
    
    IBOutlet UILabel *lblCurrentTimePrompt;
    IBOutlet UILabel *lblCurrentTime;
    
    IBOutlet UIButton *btnStartPlay;
    IBOutlet UIButton *btnEndPlay;
    
    IBOutlet UIView *vwStopPlay;
    IBOutlet UIButton *btnSetLastPlayEndTime;
    IBOutlet UIButton *btnSetLastPlayDuration;
    
    IBOutlet UIButton *btnCancel;
    
    IBOutlet UIView *vwDatePick;
    IBOutlet UIDatePicker *pckDate;
    IBOutlet UIButton *btnDatePick;
    
    @private
    NSDate *_lastPickDate;
    NSTimeInterval _lastPickDuration;
    bool _isLastPickForDate;
    NSDate *_playTimeFrom;
}

@property (nonatomic, weak) id <GRY1PlayViewControllerDelegate> delegate;

-(IBAction)btnStartPlayClick:(id)sender;
-(IBAction)btnCancelClick:(id)sender;
-(IBAction)btnEndPlayClick:(id)sender;

-(IBAction)btnSetLastPlayTimeClick:(id)sender;
-(IBAction)btnSetLastPlayDurationClick:(id)sender;

-(void) loadStateForLastPlayTime:(GRY1BabyStateEnum) newState withLastPlayTime: (NSDate*) from;

-(IBAction)btnDatePickClick:(id)sender;

@end
