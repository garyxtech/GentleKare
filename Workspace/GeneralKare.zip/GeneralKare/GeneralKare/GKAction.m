//
//  GKAction.m
//  GeneralKare
//
//  Created by 薛洪 on 13-12-1.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import "GKAction.h"


@implementation GKAction

@dynamic actionType;
@dynamic endTime;
@dynamic startTime;

@end
