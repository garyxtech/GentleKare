//
//  GKBaby.m
//  GeneralKare
//
//  Created by 薛洪 on 13-12-1.
//  Copyright (c) 2013年 薛洪. All rights reserved.
//

#import "GKBaby.h"
#import "GKAction.h"


@implementation GKBaby

@dynamic currAction;
@dynamic firstName;
@dynamic gender;
@dynamic lastName;
@dynamic recentActions;

@end
